<main>
	<div class="container">
		<div id="wizard_container">
            <div class="row justify-content-center mt-5 mb-5">
                <div class="col-6 text-center pt-5 pb-5">
                    <h1 class="display-3">ERROR 404</h1>
                    <p>Web page does not exist</p>
                </div>
            </div>
		</div>
		<!-- /Wizard container -->
	</div>
	<!-- /Container -->
</main>
<!-- /main -->