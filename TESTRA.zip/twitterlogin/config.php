<?php
    define('CONSUMER_KEY', 'cecfI9yn5a2M0wUDQxt9ptssE');
    define('CONSUMER_SECRET', 'KbUUv5rErzsvr58YfRrsT0rk5aoIiPTaiFmMYWQa9wYWyHqh9e');
    define('OAUTH_CALLBACK', 'http://testra.masrizky.com/twitterlogin/process.php');
?>