<main class="">
    <div class="container margin_60_35">
        <div class="row justify-content-center p-3 p-lg-0 ">
            <div class="col-12 jumbotron">
                <h1 class="display-4">Semangat!</h1>
                <h4 style="font-weight:300;">Yuk ketahui kepribadianmu sekarang!</h4>
                <p class="lead mt-5">
                    <a class="btn btn-primary btn-lg" href="<?php echo $url?>/?p=personality" role="button">Mulai disini</a>
                </p>
            </div>
        </div>
    </div>
</main>
<!-- /main -->