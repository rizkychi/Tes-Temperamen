<div class="modal fade" id="modal-txt" tabindex="-1" role="dialog" aria-labelledby="termsLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="termsLabel">GIVEAWAY TESTRA</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
            </div>
            <div class="modal-body">
                <h5 class="text-center text-success">HADIAH Senilai 100.000</h5>
                <p class="text-center"><i>(Untuk 2 orang pemenang @50.000)</i></p>
                <p class="mb-2 mt-4 text-primary"><strong>Syarat dan ketentuan</strong></p>
                <ol>
                    <li>Gunakan aplikasi ini untuk mengetahui temperamenmu</li>
                    <li>Hadiah berupa saldo pulsa/gopay/ovo (pilih salah satu)</li>
                    <li>Periode giveaway dari tanggal 24 - 30 Agustus 2020</li>
                    <li>Pemenang akan diumumkan tanggal 31 Agustus 2020</li>
                    <li>Pemenang yang memenuhi kriteria akan dipilih secara acak</li>
                    <li>Pemenang akan dihubungi via Direct Message Twitter oleh admin</li>
                    <li>Keputusan admin mutlak dan tidak dapat diganggu</li>
                </ol>
                <p class="mb-2 mt-4 text-primary"><strong>Kriteria pemenang</strong></p>
                <ol>
                    <li>Merupakan pengguna aktif twitter dengan jumlah tweet minimal 200</li>
                    <li>Merupakan akun personal (bukan olshop dan sebagainya)</li>
                    <li>Akun twitter tidak di private</li>
                </ol>
                <p class="mb-2 mt-4 text-center text-danger"><strong>Testra hanya mengambil informasi username twittermu dan bukan informasi pribadimu (untuk dihubungi jika menang). Jadi tentu saja aman!</strong></p>
                <h5 class="mb-2 mt-4 text-center">Jangan lupa ajak teman-temanmu untuk ikutan!</h5>
            </div>
        </div>
    </div>
</div>